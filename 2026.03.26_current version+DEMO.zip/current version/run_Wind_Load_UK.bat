@echo off
cd /d "%~dp0"
python bin\runner.py
echo Starting Wind Automation Pipeline...
echo.

python runner.py

echo.
if %ERRORLEVEL% == 0 (
    echo Pipeline completed successfully.
) else (
    echo Pipeline FAILED. See errors above.
)

pause
