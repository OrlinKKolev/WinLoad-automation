"""Orchestrate ce(z) retrieval for ALL schemes in Excel.

Workflow per row:
    1. Resolve coordinates.
    2. Compute DistanceToSea_km and Elevation_m (always fetch fresh from geo tools).
    3. Get OS eastings/northings from postcode.
    4. Build JSON with real DistanceToSea_km and Elevation_m.
    5. Website: load JSON -> OS datum -> vbmap overwritten -> Calculate -> ce(z).
    6. Write ce(z), DistanceToSea_km and Elevation_m back into Excel.
"""

from __future__ import annotations



import sys
from pathlib import Path

import pandas as pd

project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

from tools.utils import parse_number
from tools.geo.geo_location_toolset import (
    get_lat_lon_from_postcode,
    get_postcode_from_lat_lon,
    get_distance_to_sea_km,
    get_elevation_m,
    get_os_grid_from_postcode,
)
from tools.wind_json_builder import build_and_save_scheme_json
from tools.web.web_automation_toolset import load_json_calculate_get_cez

EXCEL_NAME = "wind_example.xlsx"
TEMP_DIR = project_root / "data" / "temp"
REPORTS_DIR = project_root / "data" / "reports"



def process_scheme(df: pd.DataFrame, idx: int) -> dict:
    """Process a single row. Returns dict with ce_z, dist_sea, elevation."""
    row = df.iloc[idx]

    scheme_id = row["SchemeID"]
    postcode  = str(row.get("Postcode") or "").strip()
    lat       = row.get("Latitude")
    lon       = row.get("Longitude")
    
    # ── 1. Resolve coordinates ─────────────────────────────────────────────
    if pd.notna(lat) and pd.notna(lon):
        lat = parse_number(lat)
        lon = parse_number(lon)

        # Validate ranges
        if not (-90.0 <= lat <= 90.0):
            raise ValueError(f"Row {idx} [{scheme_id}]: Latitude {lat} out of range [-90, 90]")
        if not (-180.0 <= lon <= 180.0):
            raise ValueError(f"Row {idx} [{scheme_id}]: Longitude {lon} out of range [-180, 180]")

        # Normalise to always have decimals (e.g. 51 → 51.000000)
        lat = float(f"{lat:.6f}")
        lon = float(f"{lon:.6f}")

        df.at[idx, "Latitude"] = lat
        df.at[idx, "Longitude"] = lon

    elif postcode:
        lat, lon = get_lat_lon_from_postcode(postcode)
        df.at[idx, "Latitude"] = lat
        df.at[idx, "Longitude"] = lon
    else:
        raise ValueError(f"Row {idx}: no coordinates and no postcode for SchemeID {scheme_id}")

    if not postcode:
        try:
            postcode = get_postcode_from_lat_lon(lat, lon)
            df.at[idx, "Postcode"] = postcode
        except Exception:
            pass

    # ── 2. Always fetch geodata fresh from geo tools ───────────────────────
    print(f"[{scheme_id}] Fetching distance to sea...")
    dist_sea = get_distance_to_sea_km(lat, lon)
    print(f"[{scheme_id}] Distance to sea: {dist_sea} km")

    print(f"[{scheme_id}] Fetching elevation...")
    elevation = get_elevation_m(lat, lon)
    print(f"[{scheme_id}] Elevation: {elevation} m")

    # ── 3. OS grid for vbmap ───────────────────────────────────────────────
    if not postcode:
        raise ValueError(f"Need a postcode to get OS grid for SchemeID {scheme_id}")
    os_easting, os_northing = get_os_grid_from_postcode(postcode)
    print(f"[{scheme_id}] OS datum: easting={os_easting}, northing={os_northing}")

    # ── 4. Build JSON with real geodata ────────────────────────────────────
    scheme = {
        "scheme_id":        scheme_id,
        "H":  parse_number(row["H"]),
        "DistanceToSea_km": dist_sea,
        "Elevation_m":      elevation,
        "Project":          str(scheme_id),
    }
    json_path = build_and_save_scheme_json(scheme, TEMP_DIR)
    print(f"[{scheme_id}] JSON saved: {json_path}")

    # ── 5. Website automation ──────────────────────────────────────────────
    pdf_path = REPORTS_DIR / f"scheme_{scheme_id}_wind_result.pdf"
    cez = load_json_calculate_get_cez(
        json_path=json_path,
        os_easting=os_easting,
        os_northing=os_northing,
        pdf_path=pdf_path,
        headless=True,
    )
    print(f"[{scheme_id}] ce(z) = {cez}")

    return {
        "ce_z":             cez,
        "DistanceToSea_km": dist_sea,
        "Elevation_m":      elevation,
    }


def main() -> None:
    excel_path = project_root / "data" / EXCEL_NAME

    df = pd.read_excel(excel_path, sheet_name="Schemes")
    if df.empty:
        raise RuntimeError("Schemes sheet is empty; nothing to process.")

    # Ensure output columns exist
    for col in ["ce_z", "DistanceToSea_km", "Elevation_m"]:
        if col not in df.columns:
            df[col] = None

    for idx in range(len(df)):
        scheme_id = df.at[idx, "SchemeID"]
        try:
            result = process_scheme(df, idx)
            df.at[idx, "ce_z"]             = result["ce_z"]
            df.at[idx, "DistanceToSea_km"] = result["DistanceToSea_km"]
            df.at[idx, "Elevation_m"]      = result["Elevation_m"]
        except Exception as e:
            print(f"[{scheme_id}] ERROR: {e}")
            df.at[idx, "ce_z"] = "ERROR"

        # Save after every row
        with pd.ExcelWriter(
            excel_path, mode="a", if_sheet_exists="replace", engine="openpyxl"
        ) as writer:
            df.to_excel(writer, sheet_name="Schemes", index=False)
        print(f"[{scheme_id}] Excel updated.")

    print("All schemes processed.")


if __name__ == "__main__":
    main()
