"""Web automation helpers for EurocodeApplied wind calculator.

Public functions:

- extract_cez_from_html(html)        : parse ce(z) from result HTML
- get_vbmap_from_os_datum(page, east, north)
                                     : click #vbmap, enter OS datum via dialogs,
                                       return the vb,map value the site computed
- load_json_calculate_get_cez(json_path, os_easting, os_northing, headless)
                                     : full sequence:
                                         1. open page
                                         2. enter OS datum -> vb,map is auto-filled
                                         3. load JSON (all other params)
                                         4. click CALCULATE
                                         5. return ce(z)

Nothing in this module touches Excel or geolocation APIs.
"""

from __future__ import annotations

import re
from pathlib import Path
from tools.utils import pause_for_inspection
from playwright.sync_api import sync_playwright, Page

EUROCODE_URL = (
    "https://eurocodeapplied.com/design/en1991/"
    "wind-peak-velocity-pressure-ireland-and-uk"
)


# ── Parsing ──────────────────────────────────────────────────────────────────

def extract_cez_from_text(text: str) -> float:
    """Extract ce(z) from the plain text body of the result page.

    Matches the pattern:
        ... as ce(z) = 3.160.
    """
    pattern = r"ce\(z\)\s*=\s*([0-9]+(?:\.[0-9]+)?)"
    matches = re.findall(pattern, text)
    if not matches:
        raise ValueError("Could not find ce(z) pattern in page text")
    # Last match is the actual result value (earlier ones may be in headings)
    return float(matches[-1])

# ── PDF export ───────────────────────────────────────────────────────────────

def save_result_as_pdf(page: Page, pdf_path: Path | str) -> None:
    """Save the current page as PDF using Playwright's built-in PDF export."""
    pdf_path = Path(pdf_path)
    pdf_path.parent.mkdir(parents=True, exist_ok=True)
    page.pdf(path=str(pdf_path), format="A4")
    print(f"PDF saved: {pdf_path}")

# ── vb,map via OS datum dialogs ───────────────────────────────────────────────

def get_vbmap_from_os_datum(
    page: Page,
    os_easting: int,
    os_northing: int,
) -> float:
    """Click the #vbmap button on an already-loaded calculator page,
    enter OS datum coordinates via the prompt dialog, accept the result
    alert, and return the vb,map value that the site computed.

    The page must already be open and fully loaded before calling this.
    vb,map is also transferred automatically into the form by the site's
    own JS, so after this call the vbmap input field is populated.
    """
    vbmap_value: list[float] = []

    def handle_dialog(dialog):
        if dialog.type == "prompt":
            coord_text = f"{os_easting}, {os_northing}"
            dialog.accept(coord_text)
        else:
            msg = dialog.message
            m = re.search(r"wind velocity\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*m/s", msg)
            if m:
                vbmap_value.append(float(m.group(1)))
            dialog.accept()

    page.on("dialog", handle_dialog)
    page.click("#vbmap")
    page.wait_for_timeout(2000)
    page.remove_listener("dialog", handle_dialog)

    if not vbmap_value:
        raise RuntimeError(
            f"Could not parse vb,map from OS datum dialogs for "
            f"easting={os_easting}, northing={os_northing}"
        )
    return vbmap_value[0]


# ── Full sequence ─────────────────────────────────────────────────────────────
def load_json_calculate_get_cez(
    json_path: Path,
    os_easting: int,
    os_northing: int,
    pdf_path: Path | str,
    headless: bool = True,
) -> float:
    json_path = Path(json_path)
    if not json_path.exists():
        raise FileNotFoundError(f"JSON file not found: {json_path}")

    p = sync_playwright().start()
    browser = p.chromium.launch(headless=headless)
    page = browser.new_page()
    page.goto(EUROCODE_URL, wait_until="networkidle")

    # Step 1: load JSON (vbmap=99.99 placeholder)
    page.click("button.load")
    page.set_input_files("input[type='file']", str(json_path))
    page.click("#calculation-load")
    page.wait_for_timeout(2000)

    # Step 2: overwrite vbmap with real value from OS datum
    vbmap = get_vbmap_from_os_datum(page, os_easting, os_northing)
    print(f"vb,map from OS datum: {vbmap} m/s")

    # Step 3: calculate
    page.click("#calculation-calculate")
    page.wait_for_timeout(3000)

    # Step 4: extract ce(z) from plain text (avoids HTML entity issues)
    text = page.inner_text("body")
    cez = extract_cez_from_text(text)
    print(f"ce(z) = {cez}")


    # Step 5: save result as PDF
    save_result_as_pdf(page, pdf_path)

    # Step 6: close browser
    browser.close()
    p.stop()
    
    cez = extract_cez_from_text(text)
    return cez
