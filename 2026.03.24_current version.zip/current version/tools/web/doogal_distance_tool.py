"""
Distance to sea via Doogal's DistanceToSea page.

Requires:
    pip install playwright
    playwright install
"""

from __future__ import annotations

import re
import threading

from playwright.sync_api import sync_playwright

DOOGAL_DISTANCE_URL = "https://www.doogal.co.uk/DistanceToSea"


def _dismiss_cookie_popup(page) -> None:
    """Click DISAGREE on the cookie consent popup if it appears."""
    try:
        page.wait_for_selector("text=DISAGREE", timeout=1500)
        page.click("text=DISAGREE")
    except Exception:
        pass
        pass


def _run_doogal(lat: float, lon: float, headless: bool, result: list) -> None:
    """Runs inside a dedicated thread to avoid asyncio event loop conflicts."""
    coord_line = f"{lat:.6f},{lon:.6f}"

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_page()
        page.goto(DOOGAL_DISTANCE_URL, wait_until="networkidle")

        _dismiss_cookie_popup(page)

        page.fill("textarea", coord_line)
        page.click("input[value='Calculate']")

        # Wait until the coordinate result appears in the page body
        page.wait_for_function(
            f"() => document.body.innerText.includes('{coord_line}')",
            timeout=15000
        )

        body_text = page.inner_text("body")
        pattern = r"-?\d+\.?\d*,\s*-?\d+\.?\d*\s+(\d+\.?\d*)\s+(\d+\.?\d*)"
        m = re.search(pattern, body_text)
        if not m:
            raise RuntimeError(f"Could not find distance result for {lat},{lon} in page text")

        dist_miles = float(m.group(1))
        dist_km = float(m.group(2))
        print(f"Distance: {dist_miles} miles / {dist_km} km")

        browser.close()
        result.append(dist_km)


def get_distance_to_sea_km_doogal(
    lat: float,
    lon: float,
    headless: bool = True,
) -> float:
    """
    Use Doogal 'Distance to the sea' page to get distance to sea (km)
    for a single point given by (lat, lon).

    Runs Playwright in a separate thread to avoid asyncio event loop conflicts.
    """
    result = []
    exc_holder = []

    def thread_target():
        try:
            _run_doogal(lat, lon, headless, result)
        except Exception as e:
            exc_holder.append(e)

    t = threading.Thread(target=thread_target)
    t.start()
    t.join()

    if exc_holder:
        raise exc_holder[0]

    return result[0]
