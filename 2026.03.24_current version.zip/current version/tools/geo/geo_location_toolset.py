"""Geolocation and site-parameter utilities for Wind Calc Auto.

This module centralizes all external geodata lookups:

- Coordinates (lat, lon) from UK postcodes via postcodes.io
- Nearest postcode from coordinates via postcodes.io reverse geocoding
- Distance to nearest coastline (km) from coordinates via the dist2coast_1deg grid
- Elevation (m) from coordinates via the Open-Elevation API
- OS National Grid eastings/northings from postcode via postcodes.io

All functions are pure utilities and do not depend on Excel or Playwright.
"""

from __future__ import annotations

from typing import Tuple
from tools.web.doogal_distance_tool import get_distance_to_sea_km_doogal

import requests

POSTCODES_IO_BASE = "https://api.postcodes.io/postcodes"
ELEVATION_API_BASE = "https://www.elevation-api.eu/v1/elevation"


def get_lat_lon_from_postcode(postcode: str) -> Tuple[float, float]:
    """Get (latitude, longitude) from a UK postcode using postcodes.io.

    Raises ValueError if the postcode is not found.
    """
    url = f"{POSTCODES_IO_BASE}/{postcode.replace(' ', '')}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    data = r.json()
    if data.get("status") != 200 or not data.get("result"):
        raise ValueError(f"Postcode not found: {postcode}")
    res = data["result"]
    return float(res["latitude"]), float(res["longitude"])


def get_postcode_from_lat_lon(lat: float, lon: float) -> str:
    """Get nearest UK postcode for (lat, lon) using postcodes.io reverse geocoding."""
    url = POSTCODES_IO_BASE
    params = {"lon": lon, "lat": lat}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    data = r.json()
    if data.get("status") != 200 or not data.get("result"):
        raise ValueError(f"No postcode found for coordinates {lat}, {lon}")
    return data["result"][0]["postcode"]


def get_distance_to_sea_km(lat: float, lon: float) -> float:
    """Get distance to nearest coastline (km) via Doogal's Distance to Sea page."""
    return get_distance_to_sea_km_doogal(lat, lon)



def get_elevation_m(lat: float, lon: float) -> float:
    """Get elevation (m) from coordinates using elevation-api.eu (SRTM data, no key required)."""
    r = requests.get(f"{ELEVATION_API_BASE}/{lat}/{lon}", timeout=10)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, (int, float)):
        return float(data)
    if isinstance(data, dict) and "elevation" in data:
        return float(data["elevation"])
    raise RuntimeError(f"Unexpected elevation response for ({lat}, {lon}): {data}")


def get_os_grid_from_postcode(postcode: str) -> Tuple[int, int]:
    """Get OS National Grid eastings/northings (meters) from UK postcode.

    Uses postcodes.io and returns (eastings, northings) as integers.
    """
    url = f"{POSTCODES_IO_BASE}/{postcode.replace(' ', '')}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    data = r.json()
    if data.get("status") != 200 or not data.get("result"):
        raise ValueError(f"Postcode not found: {postcode}")
    res = data["result"]
    east = int(res["eastings"])
    north = int(res["northings"])
    return east, north
